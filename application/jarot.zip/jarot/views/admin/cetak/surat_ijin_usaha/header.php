<table align="center" style="width: 90%">

    <tr>
        <td colspan="3" style="width: 100%; text-align: center;">
            <img src="<?php base_url() ?>aset/img/pancasila.png" />
        </td>
    </tr>
    <tr>
        <td style="width: 20%;">

        </td>

        <td style="width: 60%; text-align:center; vertical-align: bottom; font-size: 18px;">
            <b>WALIKOTA BALIKPAPAN</b>
        </td>

        <td style="width: 20%; vertical-align: bottom">
            Kode Pos 76100
        </td>
    </tr>

    <tr>
        <td colspan="3" style="width: 100%">
            <hr style="border-width: 2px;">
            <hr style="border-width: 1px; margin-top: -10px;">
        </td>
    </tr>
</table>