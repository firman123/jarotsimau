<table align="center" style="width: 100%">
    <tr>

        <td style="width: 40%">
            <table style="width: 100%">
                <tr>
<!--                    <td style="width: 20%"><img src="<?php echo base_url() ?>aset/img/logo_balikpapan.png" style="height: 50px"/></td>
                    <td style="width: 80%"><img src="<?php echo base_url() ?>aset/img/logo_dishub.png" style="height: 50px"/></td>--> 
                    
                    <td style="width: 20%; height: 50px;"></td>
                    <td style="width: 80%; height: 50px;"></td>
                </tr>
                <tr>
                    <td colspan="2"><b>Dinas Pemerintah Kota Balikpapan</b></td>
                </tr>
                <tr>
                    <td colspan="2"><b>Dinas Perhubungan</b></td>
                </tr>
                <tr>
                    <td colspan="2">Jl. Ruhuy Rahayu 1 Nomor 5, Balikpapan</td>
                </tr>
                <tr>
                    <td colspan="2">Telp. (0542)876291</td>
                </tr>

            </table>  
        </td>
        <td style="width: 60%">
            <p style="text-align: center; font-size: 20px"><u><b>Kwitansi</b></u></p>
<p style="text-align: center; padding-top: -30px"><i>Receipt</i></p>
</td>
</tr>
</table>