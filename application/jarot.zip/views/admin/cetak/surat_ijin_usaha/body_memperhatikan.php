<br>
<table style="width: 90%" align="center">
    <tr>
        <td style="width: 5%">1.</td>
        <td style="width: 20%">Memperhatikan</td>
        <td style="width: 5%">:</td>
        <td colspan="2" style="width: 70%">Surat Permohonan izin usaha angkutan umum dari :</td>
    </tr>
    <tr>
        <td colspan="3" style="width: 30%"></td>
        <td style="width: 15%">Nama</td>
        <td style="width: 55%">: <?php echo $datpil->nama_pimpinan ?></td>
    </tr>
    <tr>
        <td colspan="3"></td>
        <td>Tanggal</td>
        <td>: <?php echo $date_manipulation->get_full_date($datpil->tanggal_berlaku); ?></td>
    </tr>
</table>