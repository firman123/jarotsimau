<br>
<table style="width: 90%;" align="center">
    <tr style="vertical-align: top">
        <td style="width: 5%">2. </td>
        <td style="width: 25%">Mengingat </td>
        <td style="width: 5%">: </td>
        <td style="width: 5%">1. </td>
        <td style="width: 60%">Undang - Undang Nomor 22 Tahun 2009 tentang lalulintas Angkutan jalan</td>
    </tr>
    <tr style="vertical-align: top">
        <td style="width: 5%"></td>
        <td style="width: 25%"></td>
        <td style="width: 5%"></td>
        <td style="width: 5%">2. </td>
        <td style="width: 60%"> Peraturan Pemerintah Nomor 74 Tahun 2016 tentang Angkutan </td>
    </tr>

    <tr style="vertical-align: top">
        <td style="width: 5%"></td>
        <td style="width: 25%"></td>
        <td style="width: 5%"></td>
        <td style="width: 5%">3. </td>
        <td style="width: 60%"> Peraturan Pemerintah Nomor 55 Tahun 2012 tentang Kendaraan </td>
    </tr> 

    <tr style="vertical-align: top">
        <td style="width: 5%"></td>
        <td style="width: 25%"></td>
        <td style="width: 5%"></td>
        <td style="width: 5%">4. </td>
        <td style="width: 60%"> Peraturan Daerah Kota Balikpapan Nomor 7 Tahun 2000 tentang izin Angkutan Umum </td>
    </tr>
</table>