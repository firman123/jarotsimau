<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <head>
        <title>SCAN KP</title>
        <link rel="stylesheet" href="<?php echo base_url(); ?>aset/css/bootstrap.css">

        <link rel="stylesheet" href="<?php echo base_url(); ?>aset/js/jquery/jquery-ui.css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>aset/css/jquery.autocomplete.css"/>

        <script src="<?php echo base_url(); ?>aset/js/bootstrap.min.js"></script>
    </head>
    <body style="background: #fff;">
        <div class="container">
            <div class="row">
                <table class="table">
                    <thead>
                        <tr>
                            <th colspan="5">Informasi Perusahaan</th>  
                        </tr>                    
                    </thead>
                    <tbody>
                        <tr>
                            <td style="width: 15%;">No. KP</td>
                            <td width="1%">:</td>
                            <td width="30%"></td>

                            <td style="width: 20%;">No. Rangka</td>
                            <td width="1%">:</td>
                            <td width="35%"></td>
                        </tr>
                        <tr>
                            <td style="width: 15%">No. Uji</td>
                            <td width="1%">:</td>
                            <td width="30%"></td>

                            <td style="width: 20%;">No. Mesin</td>
                            <td width="1%">:</td>
                            <td width="35%"></td>
                        </tr>

                        <tr>
                            <td>No. Kendaraan</td>
                            <td width="1%">:</td>
                            <td></td>

                            <td>JBI</td>
                            <td width="1%">:</td>
                            <td></td>
                        </tr>

                        <tr>
                            <td>Nama Pemilik</td>
                            <td width="1%">:</td>
                            <td></td>

                            <td>Daya Angkut Orang</td>
                            <td width="1%">:</td>
                            <td></td>
                        </tr>

                        <tr>
                            <td>Nama Perusahaan</td>
                            <td width="1%">:</td>
                            <td></td>

                            <td>Daya Angkut Barang</td>
                            <td width="1%">:</td>
                            <td></td>
                        </tr>

                        <tr>
                            <td>Nama Pengemudi</td>
                            <td width="1%">:</td>
                            <td></td>

                            <td>Masa Berlaku Uji</td>
                            <td width="1%">:</td>
                            <td></td>

                        </tr>

                        <tr>
                            <td colspan="3">Bejo Sudirjo</td>

                            <td>Masa Berlaku KP</td>
                            <td width="1%">:</td>
                            <td></td>
                        </tr>

                        <tr>
                            <td>Nomor Trayek</td>
                            <td width="1%">:</td>
                            <td></td>

                            <td>Lintasan</td>
                            <td width="1%">:</td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>

            </div>
            
            <div class="row">
                
            </div>
        </div>
    </body>
</html>