<br><br><br><br><br>
<table style="width: 90%;" align="center">
    <tr>
        <td style="width: 5%">3.</td>
        <td style="width: 95%">
            Memberikan izin kepada :
        </td>
    </tr>
</table>


<table style="width: 80%;" align="center">
    <tr>
        <td style="width: 5%">3.1</td>
        <td style="width: 25%">Nama</td>
        <td style="width: 30%">:  <?php echo $pimpinan;?></td>
    </tr>
    <tr>
        <td>3.2</td>
        <td>Jabatan / Kedudukan</td>
        <td>:  Pimpinan Perusahaan</td>
    </tr>
    <tr>
        <td>3.3</td>
        <td>Alamat</td>
        <td>:  <?php echo $datpil->alamat; ?></td>
    </tr>
    <tr>
        <td>3.4</td>
        <td>Nama Badan Usaha</td>
        <td>:  <?php echo $datpil->nama_perusahaan ?></td>
    </tr>
    <tr>
        <td>3.5</td>
        <td>Alamat Badan Usaha</td>
        <td>:  <?php echo $datpil->alamat_perusahaan ?></td>
    </tr>
    <tr>
        <td>3.6</td>
        <td>N P W P</td>
        <td>:  <?php echo $datpil->npwp ?></td>
    </tr>

</table>

<table style="width: 80%;" align="center">
    <tr>
        <td style="width: 100%;">
            Untuk Melaksanakan USAHA UMUM ANGKUTAN PENUMPANG

        </td>
    </tr>
</table>
