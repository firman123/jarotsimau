<htm>
    <head>
        <style type="text/css" media="print">
            @page
            {
                size: 11cm 11cm;
                margin-left: -0.2cm;
                margin-top: -0.2cm;
                margin-right: 0cm;
                margin-bottom: 0cm;
            }

            #kotak {
                width:9.5cm;
                height:9.5cm;
            }  

            table, tr, td {
            }

            .text_terbalik {
                -webkit-transform: rotate(180deg);
                -moz-transform: rotate(180deg);
                writing-mode: lr-tb;

            }
	

            .font_setting {
                font-family: Arial, Helvetica, sans-serif;
                font-size: 28px;
                font-style: normal;
                font-weight: bold; 
            }

		.font_setting2 {
                font-family: Arial, Helvetica, sans-serif;
                font-size: 48px;
                font-style: normal;
                font-weight: bold; 
            }

            .font_header {
                font-family: Arial, Helvetica, sans-serif;
                font-size: 12px;
                font-style: normal;
                text-align: center;
                width: 100%; 
                text-transform: uppercase;
            }

            .text_padding {
                padding: 10px;
            }

            .text_bold {
                font-weight: bold
            }
        </style>

    </head>
    <body onload="window.print()">
	<table style="width: 9.5cm; height:5.5cm; margin-left: 5.5cm; margin-right: 0cm; margin-top: 0cm; margin-bottom: 0cm;">
        <tr>
		<td></td>
	</tr>

	<tr style="border-left: 0px; border-right: 0px;">
                <td rowspan="2">
			<img src="<?php echo base_url(); ?>qr.png" style="width: 150px;" />
		</td>
		<td style="width: 60%;">
                    <div class="font_setting2 text_terbalik" style="padding-left: 1cm;"><?php echo $datpil->kd_trayek; ?></div>
                </td>
		

            </tr>
	<tr>
                <td  style="height: 1.2cm;">
                    <div class="font_setting text_terbalik" style=" vertical-align: bottom; padding-top: 0.1cm;padding-left: 0.2cm;"><?php echo $datpil->no_kendaraan; ?></div>
                </td>
		
            </tr>
	<tr>
                <td colspan="2" style="height: 2cm;">
                    <div class="font_setting text_padding text_terbalik" style=" vertical-align: bottom; padding-top: 0.1cm; text-align: right;"><?php echo $date_manipulation->get_full_date($datpil->tgl_mati_uji); ?></div>
                </td>
            </tr>

	<tr>
                <td colspan="2" style="height: 1.7cm;">
                    <div class="font_setting text_padding text_terbalik" style=" vertical-align: bottom;padding-top: 0.1cm;  text-align: right;"><?php echo $datpil->kp_ijin_trayek; ?></div>
                </td>
            </tr>


<tr>
                <td colspan="2">
                    <div style="height: 1cm;">
                    </div>
                </td>
            </tr>        


        </table>

        <table style="width: 9.5cm; height:5.5cm; margin-left: 5.5cm; margin-right: 0cm; margin-top: 0cm; margin-bottom: 0cm;">
            <tr>
                <td colspan="2">
                    <div style="height: 3.3cm;">
                    </div>
                </td>
            </tr>

            <tr>
                <td colspan="2" style="height: 1.7cm;">
                    <div class="font_setting text_padding" style=" vertical-align: bottom; padding-top: 0.1cm; text-align: right;"><?php echo $datpil->kp_ijin_trayek; ?></div>
                </td>
            </tr>

            <tr>
                <td colspan="2" style="height: 2cm;">
                    <div class="font_setting text_padding" style=" vertical-align: bottom; padding-top: 0.1cm; text-align: right;"><?php echo $date_manipulation->get_full_date($datpil->tgl_mati_uji); ?></div>
                </td>
            </tr>

            <tr>
                <td  style="height: 1.5cm;">
                    <div class="font_setting text_padding" style=" vertical-align: bottom; padding-top: 0.1cm;padding-left: 0.2cm;"><?php echo $datpil->no_kendaraan; ?></div>
                </td>
		<td rowspan="2">
			<img src="<?php echo base_url(); ?>qr.png" style="width: 150px;" />
		</td>
            </tr>


            <tr style="border-left: 0px; border-right: 0px;">
                <td style="width: 60%;">
                    <div class="font_setting2" style="padding-left: 1cm;"><?php echo $datpil->kd_trayek; ?></div>
                </td>


            </tr>
        <tr>
		<td></td>
	</tr>


        </table>
    </body>
</htm>



