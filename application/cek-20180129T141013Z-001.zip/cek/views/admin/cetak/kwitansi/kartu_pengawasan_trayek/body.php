<table style="width: 100%" border="1">
    <tr>
        <td style="width: 30%">
    <u style="margin-bottom: 10px">Telah Diterima Dari</u>
        </td>
        <td style="width: 5%">:</td>
        <td style="width: 55%"><b><?php echo $datpil->nama_perusahaan; ?></b></td>
    </tr>
    <tr>
        <td colspan="3"><i>Receipt From</i></td>
    </tr>
    
    <tr>
        <td>
    <u>Sejumlah Uang</u>
        </td>
        <td>:</td>
        <td><b><?php echo $kuitansi->keterangan;?></b></td>
    </tr>
    <tr>
        <td colspan="3"><i>Amount receif</i></td>
    </tr>
    
    <tr>
        <td>
    <u>Untuk Pembayaran</u>
        </td>
        <td>:</td>
        <td>Retribusi kartu pengawasan trayek</td>
    </tr>
    <tr>
        <td colspan="3"><i>In Payment Of</i></td>
    </tr>
</table>