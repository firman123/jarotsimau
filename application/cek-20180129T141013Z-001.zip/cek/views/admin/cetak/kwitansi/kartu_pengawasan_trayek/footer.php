<table style="width: 90%">
    <tr>
        <td style="width: 50%">
            <div style="font-size: 20px; background-color: #ccccff; padding: 5px; float: right; height: 10px; width: 200px;">
                <b>Rp. <?php echo $kuitansi->harga;?>,-</b>
            </div>
        </td>

        <td style="width: 50%">
            <div>
                
                <p>
                     <div style="text-align: center">
                    Balikpapan, <?php echo $date_manipulation->get_full_date($tanggal_cetak); ?>
                     </div></p>
                <p>  
                     <div style="text-align: center">
                    Bendahara Penerima <br>
                    Dinas Perhubungan<br><br><br><br><br><br>
                     </div>
                <div style="text-align: center">
                    Misni
                    <hr>
                    NIP. 19820908 201101 1 005
                </div>

                </p>


            </div>
        </td>
    </tr>
</table>