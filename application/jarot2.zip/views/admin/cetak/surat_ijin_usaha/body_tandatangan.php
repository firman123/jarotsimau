<br><br><br>
<table style="width: 90%" align="center">
    <tr>
        <td style="width: 70%"></td>
        <td style="width: 30%">Balikpapan, <?php echo $date_manipulation->get_full_date($datpil->tanggal_berlaku); ?></td>
    </tr>
    <tr style="text-align: center;">
        <td></td>
        <td>
           WALIKOTA BALIKPAPAN
           <br><br><br><br><br><br>
           RIZAL EFENDI
        </td>
    </tr>
</table>
